function [output] = emissions(demand,PV_fields,PV_rooftops)

emissions = zeros(length(demand),1);
Trans = (.95)*(.95); %to Eilat, transmission and transformation
GT_Eilat = 0;%(34+58)*(.95); %Gas Turbines (MW) with other consumers
EF_Gas = .400; %emissions factor for GT
EF_Grid = .645; %emissions factor for Israeli Grid

for k=1:length(demand)
    
    if isnan(demand(k))
        demand(k) = 0;
    end
    if demand(k) == 0
        emissions(k)=0;
        continue 
    end
    
    fueled = demand(k) - ( PV_fields(k)*Trans + PV_rooftops(k) )/10^6 ; %all in MW
    
    if fueled>0 && fueled<=GT_Eilat
        emissions(k) = fueled*(EF_Gas) ; %tons CO2/MW
    elseif fueled>GT_Eilat
        emissions(k) = GT_Eilat*(EF_Gas)+(fueled-GT_Eilat)*(EF_Grid) ;
    end
    %else
     %   emission(k)=fueled*(4/5); %used for storage
    %end
end
    
    output = emissions;
    %total=sum(emissions)

end