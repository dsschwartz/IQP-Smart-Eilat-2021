function [output] = monthly_comp(PV, GT, grid)
 
output = zeros(12,3);

if length(PV)>=8761
  figure
  title("warning, last entry may be annual total")
  plot(PV)
end

months = zeros(31,12);
months([29:31],2)=NaN;months(31,4)=NaN;months(31,6)=NaN;months(31,9)=NaN;months(31,11)=NaN; 
h=1;

for m=1:12
    
  num_days = 31 - sum(isnan(months([1:31],m)));
  num_hours = 24*num_days;
  
  temp1 = PV(h:h+num_hours-1); temp2 = GT(h:h+num_hours-1); temp3 = grid(h:h+num_hours-1);
  
  %[G,T,P] = compositions(temp1,temp2,temp3);
  
  output(m,1)=sum(temp1) ; output(m,2)=sum(temp2) ; output(m,3)=sum(temp3);
  
  h=h+num_hours;
        
end

end

