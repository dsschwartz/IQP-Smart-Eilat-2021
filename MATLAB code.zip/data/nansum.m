function [outputArg1] = nansum(inputArg1)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = 0;
for n=1:length(inputArg1)
    if isnan(inputArg1(n))
        inputArg1(n) = 0;
    else
        outputArg1 = outputArg1 + inputArg1(n) ;
    end
end

end

