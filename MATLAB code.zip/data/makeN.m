function [output] = makeN(input)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
output=input;
for n=1:length(input)
    if isnan(output(n))
        output(n) = 0;
    end
end

end

