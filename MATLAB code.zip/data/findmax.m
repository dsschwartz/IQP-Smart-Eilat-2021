function [value,hour] = findmax(input)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
temp=input(1);
h=1;
for n=2:length(input)
    if input(n)>temp
        temp=input(n);
        h=n;
    end
end
 value = temp;
 hour=h;
 

end

