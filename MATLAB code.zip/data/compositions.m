function [PV, GT, Grid] = compositions(Demand,PV_fields,PV_roofs)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
GDoutput=zeros(length(Demand),1); GToutput=zeros(length(Demand),1); PVoutput=zeros(length(Demand),1);
trans = (.95)*(.95); %to Eilat, transmission and transformation
GT_Eilat = 0;%(34+58)*(.95); %Gas Turbines (MW) with transformers

    PV_supply = (PV_fields*trans + PV_roofs)/10^6 ; %all in MW

for k=1:length(Demand)
    
    if isnan(Demand(k))
        Demand(k) = 0;
    end
    if Demand(k) == 0
        GDoutput(k)=0;GToutput(k)=0;PVoutput(k)=0;
        continue 
    end
    
    if PV_supply(k) >= Demand(k)
        
        PVoutput(k) = Demand(k) ;
        
    elseif PV_supply(k)+ GT_Eilat >= Demand(k)
        PVoutput(k) = PV_supply(k) ;
        GToutput(k) = Demand(k) - PV_supply(k) ;
    else
        PVoutput(k) = PV_supply(k) ;
        GToutput(k) = GT_Eilat ;
        GDoutput(k) = Demand(k) - PV_supply(k) - GT_Eilat ;
    end
 
end

PV = PVoutput;
GT = GToutput;
Grid = GDoutput;

end