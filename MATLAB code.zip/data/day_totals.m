function [output] = day_totals(hourly_power)

for n=1:length(hourly_power)
    if isnan(hourly_power(n))
        hourly_power(n) = 0;
    end
end

monthly_total = zeros(24,12);
months = zeros(31,12);
months([29:31],2)=NaN;months(31,4)=NaN;months(31,6)=NaN;months(31,9)=NaN;months(31,11)=NaN; 
h=1;

for m=1:12
  if h>=8761
      figure
      plot(hourly_power)
  end
  num_days = 31 - sum(isnan(months([1:31],m)));
  temp = zeros(24,num_days);
    for k = 1:num_days
        temp([1:24],k) = hourly_power(h+24*(k-1):h-1+24*k) ;
    end
    
    total = sum(temp,2);
    monthly_total([1:24],m) = transpose(total);
    
    h=h+24*num_days;
end

output = monthly_total;

end

